# M.O.T.I.O.N. — aplicativo Expo

Projeto React Native/Expo para Android. O repositório contém o app em `frontend/`, a API PHP em `backend/`, o banco inicial em `database/` e o Docker Compose para desenvolvimento local.

## Qual link usar?

O **link do GitHub guarda o código-fonte**; ele não abre o app no Expo Go nem hospeda a API PHP. Para testar pelo Expo Go, inicie o servidor Expo e leia o QR Code. Para instalar como aplicativo Android sem depender do Expo Go, gere um APK com EAS Build; a Expo fornecerá um link de download.

## Pelo celular Android com Termux

Instale o Termux por uma fonte oficial, abra-o e rode:

```bash
pkg update -y
pkg install -y nodejs git
npm install -g eas-cli
```

Clone o repositório do GitHub e acesse a pasta do app (substitua o endereço e o nome pelos do seu repositório):

```bash
git clone https://github.com/SEU_USUARIO/SEU_REPOSITORIO.git
cd SEU_REPOSITORIO/frontend
npm ci
```

### Abrir no Expo Go

```bash
npx expo start --tunnel
```

Deixe o Termux aberto e leia o QR Code com o Expo Go. O QR/link é temporário e corresponde ao servidor de desenvolvimento em execução; **não é o link do GitHub**. Se o Expo solicitar a instalação do suporte a tunnel, aceite e repita o comando. O telefone precisa ter o Expo Go instalado e compatível com a versão do SDK do projeto.

Se Termux e Expo Go estiverem no mesmo celular, não tente apontar a câmera para a tela do próprio aparelho: copie o endereço `exp://...` que o Expo imprime no terminal e, no Expo Go, use **Enter URL manually** para colar o endereço. Se essa opção não aparecer na versão instalada, mostre o QR em um segundo aparelho ou computador e escaneie com o celular.

### Gerar um APK instalável

```bash
eas login
eas build:configure
eas build -p android --profile preview
```

Na primeira configuração, confirme as perguntas da Expo. O build `preview` já está configurado para gerar um APK; ao concluir, abra o link de instalação que a Expo apresentar no Termux. O build ocorre nos servidores da Expo, então mantenha a conexão com a internet. `eas login` requer uma conta Expo.

O Expo Go serve para testes. O APK gerado pelo EAS é um aplicativo separado, instalável no Android.

## API e modo offline

O app oferece um modo local com dados salvos no aparelho e funciona sem hospedar o backend. Para usar cadastro/login online, sincronização entre aparelhos ou recursos do servidor, publique também `backend/` e configure o MySQL; GitHub não executa essa API nem o banco por si só. O `docker-compose.yml` é apenas para desenvolvimento local.

Para conectar o app a uma API, copie `frontend/.env.example` para `frontend/.env` e configure a URL alcançável pelo celular, por exemplo:

```env
EXPO_PUBLIC_API_URL=https://SEU_DOMINIO/api.php
APP_API_BASE_URL=https://SEU_DOMINIO/api.php
```

Use uma URL HTTPS pública para o app instalado. Em desenvolvimento local, pode usar o IP LAN do computador com Docker, por exemplo `http://IP_DO_COMPUTADOR:8080/api.php`, com celular e computador na mesma rede Wi-Fi; não use `localhost` no telefone. Depois de mudar o `.env`, pare e reinicie o Expo com `npx expo start --tunnel -c`. **Não envie `.env` ao GitHub**; as variáveis `EXPO_PUBLIC_*` são incorporadas ao app e não devem conter senhas nem chaves secretas.

O Compose não contém senhas embutidas. Antes de iniciar o backend local, faça `cp .env.example .env`, edite `.env` e substitua ambos os valores por senhas fortes diferentes. Esse `.env` é ignorado pelo Git. Proteja o banco, o PHP e o acesso à API antes de qualquer publicação na internet; não exponha o servidor de desenvolvimento do computador como API pública.

## Preparar o repositório no GitHub

Na pasta raiz do projeto (um nível acima de `frontend/`), após criar um repositório vazio no GitHub, pode enviar o código assim. Se estiver na pasta `frontend/`, primeiro volte um nível com `cd ..`:

```bash
git init
git add .
git commit -m "Preparar aplicativo MOTION"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/SEU_REPOSITORIO.git
git push -u origin main
```

Se o repositório já existir, não repita `git init` nem `git remote add`; confira primeiro com `git status` e `git remote -v`. GitHub poderá solicitar autenticação no `git push`.

## Observação sobre acesso local

O código original tem um acesso local protegido cuja senha está fixa no próprio app (`MOTION2026`). Isso não substitui uma autenticação segura e qualquer pessoa com acesso ao código-fonte pode encontrá-la. Não use essa senha como proteção de dados sensíveis.

## Pastas principais

- `frontend/`: aplicativo Expo, dependências e configuração EAS.
- `backend/`: API PHP e recursos usados pelo serviço local/hardware.
- `database/init.sql`: esquema e dados iniciais do MySQL.
- `docker-compose.yml`: ambiente de desenvolvimento do backend e banco.
- `.gitignore`: exclui dependências, cache, arquivos locais `.env` e builds gerados.

Para instalar dependências, use `npm ci` dentro de `frontend/`; o comando usa o `package-lock.json`.

## Configuração local do backend

Com Docker instalado, crie primeiro suas credenciais locais e depois inicie os serviços, na raiz:

```bash
cp .env.example .env
# Edite .env e troque os valores de exemplo por senhas fortes.
docker compose up -d --build
```

Isso inicia o MySQL e a API PHP localmente, na porta 8080. Para usar essa API a partir de um telefone físico, configure no `.env` do app o IP LAN do computador, conforme descrito acima. O modo offline não precisa desse passo.

> Antes de distribuir o app ou disponibilizar a API publicamente, configure domínio/HTTPS, credenciais exclusivas, backups do banco e controles de acesso apropriados.

## Licenças de recursos

Antes de publicar o repositório publicamente ou distribuir o app, confirme que você tem autorização para redistribuir todos os arquivos de áudio e imagem incluídos.

> O projeto foi organizado para commit e inicialização. A publicação no GitHub, o login na Expo e o build EAS devem ser feitos na sua própria conta e não foram executados nesta preparação.
